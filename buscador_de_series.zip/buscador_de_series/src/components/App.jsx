import { BarraBusqueda } from './BarraBusqueda'
import { LienzoPrincipal } from './Lienzo'

function App () {
  return (
    <section>
      <BarraBusqueda />
      <LienzoPrincipal />
    </section>

  )
}

export default App
