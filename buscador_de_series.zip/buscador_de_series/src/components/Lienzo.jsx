export const LienzoPrincipal = () => {
  return (
    <>
      <p>Soy el lienzo</p>
    </>
  )
}
